package com.jadeclient.config;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Path;

/**
 * jade-config runs as a Fabric client entrypoint purely to instantiate the
 * config store (with a no-op SPI) before jade-core boots. jade-core then
 * re-installs the real store with its SPI implementation.
 */
public final class ConfigInit implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		Path root = FabricLoader.getInstance().getGameDir().resolve("jade");
		new JadeConfigImpl(root, new ConfigSpi() {
			@Override
			public void applyModuleState(com.google.gson.JsonObject modules) {
			}

			@Override
			public com.google.gson.JsonObject moduleState() {
				return new com.google.gson.JsonObject();
			}

			@Override
			public void logError(String message, Throwable error) {
				System.err.println("[jade-config] " + message);
				if (error != null) {
					error.printStackTrace();
				}
			}

			@Override
			public void logWarn(String message) {
				System.out.println("[jade-config] " + message);
			}
		});
	}
}
