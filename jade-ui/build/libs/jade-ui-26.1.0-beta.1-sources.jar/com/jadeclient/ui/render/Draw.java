package com.jadeclient.ui.render;

import com.jadeclient.core.util.RenderUtil;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Client drawing helpers built on top of the mapping-free math in
 * {@link RenderUtil}. All Jade UI drawing funnels through here.
 * MC 26.1 uses GuiGraphicsExtractor for GUI extraction.
 */
public final class Draw {

	private Draw() {
	}

	public static void rect(GuiGraphicsExtractor g, int x, int y, int w, int h, int argb) {
		g.fill(x, y, x + w, y + h, argb);
	}

	/**
	 * Rounded rectangle: center body plus side caps. Crisp at GUI
	 * scale 1-4, no shaders, no textures.
	 */
	public static void roundedRect(GuiGraphicsExtractor g, int x, int y, int w, int h, int radius, int argb) {
		int cap = Math.min(radius, Math.min(w, h) / 2);
		g.fill(x + cap, y, x + w - cap, y + h, argb);           // vertical body
		g.fill(x, y + cap, x + cap, y + h - cap, argb);         // left cap
		g.fill(x + w - cap, y + cap, x + w, y + h - cap, argb); // right cap
	}

	/** Soft glow via layered translucent expansion. */
	public static void glow(GuiGraphicsExtractor g, int x, int y, int w, int h, int argb, int layers) {
		int step = 2;
		for (int i = layers; i > 0; i--) {
			int expand = i * step;
			int a = Math.max(1, (argb >>> 24) / (i * 2));
			g.fill(x - expand, y - expand, x + w + expand, y + h + expand,
					(a << 24) | (argb & 0x00FFFFFF));
		}
	}

	public static int blend(int from, int to, float t) {
		return RenderUtil.blend(from, to, t);
	}

	public static int withAlpha(int argb, int alpha) {
		return RenderUtil.withAlpha(argb, alpha);
	}
}
