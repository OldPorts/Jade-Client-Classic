package com.jadeclient.ui;

import com.jadeclient.JadeClient;
import com.jadeclient.core.event.EventBus;
import com.jadeclient.perf.PerformanceModule;

import com.jadeclient.ui.hud.HudEditorScreen;
import com.jadeclient.ui.hud.HudRenderDispatcher;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

/**
 * jade-ui client entrypoint. Owns:
 *  - keybind handling (RShift menu, RShift HUD editor toggle, module binds)
 *  - the HUD render hook
 *  - first-launch onboarding
 */
public final class JadeClientClient implements ClientModInitializer {

	private boolean rshiftWasDown;
	private boolean hudEditorOpen;
	private long rshiftPressTime;

	@Override
	public void onInitializeClient() {
		HudElementRegistry.addLast(
				com.jadeclient.JadeClient.id("hud_elements"),
				(graphics, delta) -> HudRenderDispatcher.renderAll(graphics, false));

		ClientTickEvents.END_CLIENT_TICK.register(this::onTick);

		// Onboarding on first launch (small delay so the title screen is up).
		EventBus.get().subscribe(EventBus.ClientTick.class, e -> {
			Minecraft mc = Minecraft.getInstance();
			if (mc.screen instanceof net.minecraft.client.gui.screens.TitleScreen
					&& OnboardingScreen.shouldShow()) {
				mc.setScreen(new OnboardingScreen());
			}
		});
	}

	/** Preset helper used by the onboarding flow. */
	public static void applyPreset(String preset) {
		if (JadeClient.modules().byId("fps_boost") instanceof PerformanceModule perf) {
			perf.applyPreset(preset);
			perf.setEnabled(true);
		}
	}

	private void onTick(Minecraft mc) {
		boolean rshiftDown = GLFW.glfwGetKey(mc.getWindow().handle(), GLFW.GLFW_KEY_RIGHT_SHIFT)
				== GLFW.GLFW_PRESS;
		boolean pressed = rshiftDown && !rshiftWasDown;
		rshiftWasDown = rshiftDown;

		if (!pressed) {
			return;
		}

		long now = System.currentTimeMillis();
		if (mc.screen instanceof ClickGuiScreen || mc.screen instanceof HudEditorScreen) {
			return; // screens close themselves
		}
		if (mc.screen == null) {
			// Short tap in-game: open editor if menu was just closed; simple
			// rule: tap opens menu, double-tap within 400ms opens editor.
			if (now - rshiftPressTime < 400) {
				hudEditorOpen = true;
				HudEditorScreen.open();
			} else {
				ClickGuiScreen.open();
			}
			rshiftPressTime = now;
		} else {
			// In another screen (chat/inventory): open the menu.
			ClickGuiScreen.open();
		}
	}
}
