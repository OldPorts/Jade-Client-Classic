package com.jadeclient.ui.hud;

import com.jadeclient.JadeClient;
import com.jadeclient.ui.render.Draw;
import com.jadeclient.modules.hud.HudModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Drag-and-drop HUD editor. Shows all enabled HUD elements with selection
 * outlines; drag to move (with snapping to other elements and screen
 * centers), scroll to scale the selection.
 */
public class HudEditorScreen extends Screen {

	private HudModule dragging;
	private float dragOffX;
	private float dragOffY;

	private static final float SNAP = 6f;

	public HudEditorScreen() {
		super(Component.literal("HUD Editor"));
	}

	public static void open() {
		Minecraft.getInstance().setScreen(new HudEditorScreen());
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		// translucent backdrop
		g.fillGradient(0, 0, width, height, 0x66000000, 0x66000000);

		// alignment guides for the currently dragged element
		if (dragging != null) {
			int cx = width / 2;
			int cy = height / 2;
			float elCx = dragging.x() + dragging.renderWidth() / 2f;
			float elCy = dragging.y() + dragging.renderHeight() / 2f;
			if (Math.abs(elCx - cx) < SNAP * 2) {
				Draw.rect(g, cx, 0, 1, height, 0x8800C896);
				dragging.setPos(cx - dragging.renderWidth() / 2f, dragging.y());
				dragging.setSnapped(true);
			}
			if (Math.abs(elCy - cy) < SNAP * 2) {
				Draw.rect(g, 0, cy, width, 1, 0x8800C896);
				dragging.setPos(dragging.x(), cy - dragging.renderHeight() / 2f);
				dragging.setSnapped(true);
			}
		}

		HudRenderDispatcher.renderAll(g, true);

		g.centeredText(font, "Drag to move - Scroll to scale - ESC to save & exit",
				width / 2, height - 14, 0xFFFFFFFF);
	}

	@Override
	public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent event, boolean doubled) {
		double mouseX = event.x();
		double mouseY = event.y();
		HudModule hit = hudAt(mouseX, mouseY);
		if (hit != null) {
			dragging = hit;
			dragOffX = (float) (mouseX - hit.x());
			dragOffY = (float) (mouseY - hit.y());
			return true;
		}
		return super.mouseClicked(event, doubled);
	}

	@Override
	public boolean mouseDragged(net.minecraft.client.input.MouseButtonEvent event, double dx, double dy) {
		double mouseX = event.x();
		double mouseY = event.y();
		if (dragging != null) {
			dragging.setSnapped(false);
			dragging.setPos((float) (mouseX - dragOffX), (float) (mouseY - dragOffY));
			return true;
		}
		return super.mouseDragged(event, dx, dy);
	}

	@Override
	public boolean mouseReleased(net.minecraft.client.input.MouseButtonEvent event) {
		if (dragging != null) {
			dragging = null;
			com.jadeclient.config.JadeConfig.get().save();
		}
		return super.mouseReleased(event);
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double dx, double dy) {
		HudModule hit = hudAt(mouseX, mouseY);
		if (hit != null) {
			hit.setScale(hit.scale() + (float) dy * 0.1f);
			return true;
		}
		return super.mouseScrolled(mouseX, mouseY, dx, dy);
	}

	private HudModule hudAt(double mx, double my) {
		HudModule best = null;
		for (var module : JadeClient.modules().modules()) {
			if (module instanceof HudModule hud && module.isEnabled()) {
				float w = hud.renderWidth() * hud.scale();
				float h = hud.renderHeight() * hud.scale();
				if (mx >= hud.x() && mx <= hud.x() + w && my >= hud.y() && my <= hud.y() + h) {
					best = hud; // topmost wins
				}
			}
		}
		return best;
	}

	@Override
	public boolean keyPressed(net.minecraft.client.input.KeyEvent event) {
		if (event.key() == 256) { // ESC
			com.jadeclient.config.JadeConfig.get().save();
			com.jadeclient.ui.ToastManager.info("HUD layout saved");
			Minecraft.getInstance().setScreen(null);
			return true;
		}
		return super.keyPressed(event);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
