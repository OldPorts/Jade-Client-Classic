package com.jadeclient.ui.hud;

import com.jadeclient.JadeClient;
import com.jadeclient.ui.render.Draw;
import com.jadeclient.modules.hud.ArmorHudModule;
import com.jadeclient.modules.hud.ClockHudModule;
import com.jadeclient.modules.hud.CompassHudModule;
import com.jadeclient.modules.hud.EffectsHudModule;
import com.jadeclient.modules.hud.FpsHudModule;
import com.jadeclient.modules.hud.HudModule;
import com.jadeclient.modules.hud.InfoHudModule;
import com.jadeclient.modules.hud.KeystrokesModule;
import com.jadeclient.modules.hud.WatermarkModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Draws every enabled HudModule at its stored position/scale. One draw pass
 * per module; modules stay dumb data holders so this file is the only place
 * that knows how to paint them.
 */
public final class HudRenderDispatcher {

	private HudRenderDispatcher() {
	}

	public static void renderAll(GuiGraphicsExtractor g, boolean editorMode) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null && !editorMode) {
			return; // nothing to show on menus
		}
		for (var module : JadeClient.modules().modules()) {
			if (module instanceof HudModule hud && module.isEnabled()) {
				var pose = g.pose();
				pose.pushMatrix();
				pose.translate(hud.x(), hud.y());
				pose.scale(hud.scale(), hud.scale());
				render(g, mc, mc.font, hud, editorMode);
				pose.popMatrix();
			}
		}
	}

	private static void render(GuiGraphicsExtractor g, Minecraft mc, Font font, HudModule hud, boolean editorMode) {
		switch (hud) {
			case FpsHudModule fps -> drawFps(g, font, fps);
			case InfoHudModule info -> drawInfo(g, font, info);
			case KeystrokesModule keys -> drawKeystrokes(g, font, keys);
			case ArmorHudModule armor -> drawArmor(g, armor);
			case EffectsHudModule effects -> drawEffects(g, font, effects);
			case ClockHudModule clock -> drawClock(g, font, clock);
			case CompassHudModule compass -> drawCompass(g, font, compass);
			case WatermarkModule wm -> drawWatermark(g, font, wm);
			default -> { /* handled elsewhere */ }
		}

		if (editorMode) {
			// dashed selection box
			int w = hud.renderWidth();
			int h = hud.renderHeight();
			Draw.rect(g, 0, 0, w, 1, 0xFF00C896);
			Draw.rect(g, 0, h - 1, w, 1, 0xFF00C896);
			Draw.rect(g, 0, 0, 1, h, 0xFF00C896);
			Draw.rect(g, w - 1, 0, 1, h, 0xFF00C896);
		}
	}

	private static void drawFps(GuiGraphicsExtractor g, Font font, FpsHudModule m) {
		float fps = m.fps();
		int color = m.fpsColor(fps);
		g.text(font, (int) fps + " FPS", 0, 0, color);
		int y = 10;
		if (m.showLow1Pct.get()) {
			g.text(font, "1% " + (int) m.low1(), 0, y, 0xFF9AA3B2);
			y += 10;
		}
		if (m.showGraph.get()) {
			float[] graph = m.graph();
			int gw = 84;
			int gh = 20;
			for (int i = 0; i < graph.length && i < gw; i++) {
				float ft = graph[i];
				float norm = Math.min(1f, ft / 50f); // 50ms = bottom
				int barH = Math.max(1, (int) (gh * (1f - norm)));
				int x = i;
				g.fill(x, y + gh - barH, x + 1, y + gh, 0x8800C896);
			}
		}
	}

	private static void drawInfo(GuiGraphicsExtractor g, Font font, InfoHudModule m) {
		var mc = Minecraft.getInstance();
		int y = 0;
		if (mc.player == null) {
			return;
		}
		if (m.coords.get()) {
			g.text(font, String.format("XYZ %.0f %.0f %.0f",
					mc.player.getX(), mc.player.getY(), mc.player.getZ()), 0, y, 0xFFFFFFFF);
			y += 10;
		}
		if (m.biome.get() && mc.level != null) {
			var biome = mc.level.getBiome(mc.player.blockPosition());
			String name = biome.unwrapKey()
					.map(k -> k.identifier().getPath())
					.orElse("?");
			g.text(font, "Biome " + name, 0, y, 0xFFFFFFFF);
			y += 10;
		}
		if (m.dimension.get() && mc.level != null) {
			g.text(font, mc.level.dimension().toString(), 0, y, 0xFFFFFFFF);
			y += 10;
		}
		if (m.server.get()) {
			String ip = mc.getSingleplayerServer() != null ? "Singleplayer"
					: mc.getCurrentServer() != null ? mc.getCurrentServer().ip : "";
			if (!ip.isEmpty()) {
				g.text(font, ip, 0, y, 0xFFFFFFFF);
				y += 10;
			}
		}
		if (m.showPing() && mc.getConnection() != null && mc.player != null) {
			var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
			int ping = info != null ? info.getLatency() : 0;
			g.text(font, ping + " ms", 0, y, 0xFFFFFFFF);
			y += 10;
		}
		if (m.direction.get()) {
			float yaw = (mc.player.getYRot() % 360f + 360f) % 360f;
			String dir = yaw < 45 || yaw >= 315 ? "N" : yaw < 135 ? "W" : yaw < 225 ? "S" : "E";
			g.text(font, dir, 0, y, 0xFF00C896);
			y += 10;
		}
	}

	private static void drawKeystrokes(GuiGraphicsExtractor g, Font font, KeystrokesModule m) {
		int size = 18;
		int gap = 2;
		// W row
		drawKey(g, font, "W", size, gap * 2 + size, 0, m.w, 0xFFFFFFFF);
		// A S D row
		drawKey(g, font, "A", size, 0, size + gap, m.a, 0xFFFFFFFF);
		drawKey(g, font, "S", size, size + gap, size + gap, m.s, 0xFFFFFFFF);
		drawKey(g, font, "D", size, (size + gap) * 2, size + gap, m.d, 0xFFFFFFFF);
		if (m.showMouse.get()) {
			String l = m.showCps.get() ? "LMB " + m.cpsL : "LMB";
			String r = m.showCps.get() ? "RMB " + m.cpsR : "RMB";
			int half = (size * 3 + gap * 2) / 2 - gap / 2;
			drawKey(g, font, l, half, 0, (size + gap) * 2, m.lmb, 0xFFFFFFFF);
			drawKey(g, font, r, half, half + gap, (size + gap) * 2, m.rmb, 0xFFFFFFFF);
		}
	}

	private static void drawKey(GuiGraphicsExtractor g, Font font, String label, int size, int x, int y,
			boolean pressed, int argb) {
		int bg = pressed ? 0x8800C896 : 0x660E1116;
		Draw.roundedRect(g, x, y, size, size, 3, bg);
		g.centeredText(font, label, x + size / 2, y + (size - font.lineHeight) / 2, pressed ? 0xFFFFFFFF : argb);
	}

	private static void drawArmor(GuiGraphicsExtractor g, ArmorHudModule m) {
		var player = Minecraft.getInstance().player;
		if (player == null) {
			return;
		}
		var slots = new net.minecraft.world.entity.EquipmentSlot[]{
			net.minecraft.world.entity.EquipmentSlot.HEAD,
			net.minecraft.world.entity.EquipmentSlot.CHEST,
			net.minecraft.world.entity.EquipmentSlot.LEGS,
			net.minecraft.world.entity.EquipmentSlot.FEET };
		int i = 0;
		for (var slot : slots) {
			var stack = player.getItemBySlot(slot);
			if (stack.isEmpty()) {
				i++;
				continue;
			}
			int x = m.horizontal() ? i * 20 : 0;
			int y = m.horizontal() ? 0 : i * 20;
			g.item(stack, x, y);
			if (m.showDurability.get() && stack.isDamageableItem()) {
				float frac = 1f - (float) stack.getDamageValue() / stack.getMaxDamage();
				int barW = (int) (16 * frac);
				int color = frac > 0.5f ? 0xFF00C896 : frac > 0.25f ? 0xFFFFC857 : 0xFFFF6B6B;
				g.fill(x, y + 17, x + 16, y + 19, 0xFF222222);
				g.fill(x, y + 17, x + barW, y + 19, color);
			}
			i++;
		}
	}

	private static void drawEffects(GuiGraphicsExtractor g, Font font, EffectsHudModule m) {
		var player = Minecraft.getInstance().player;
		if (player == null) {
			return;
		}
		int y = 0;
		for (var effect : player.getActiveEffects()) {
			String line = shorten(effect.getEffect().value());
			g.text(font, line, 0, y, 0xFFFFFFFF);
			y += 10;
		}
	}

	private static String shorten(net.minecraft.world.effect.MobEffect effect) {
		String id = net.minecraft.core.registries.BuiltInRegistries.MOB_EFFECT.getKey(effect).getPath();
		String[] parts = id.split("_");
		StringBuilder sb = new StringBuilder();
		for (String p : parts) {
			sb.append(Character.toUpperCase(p.charAt(0)));
		}
		return sb.toString();
	}

	private static void drawClock(GuiGraphicsExtractor g, Font font, ClockHudModule m) {
		String real = java.time.LocalTime.now().withSecond(0).withNano(0).toString();
		g.text(font, real, 0, 0, 0xFFFFFFFF);
		if (m.showSession.get()) {
			g.text(font, m.sessionTime(), 0, 10, 0xFF9AA3B2);
		}
	}

	private static void drawCompass(GuiGraphicsExtractor g, Font font, CompassHudModule m) {
		float yaw = m.yaw();
		String[] dirs = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
		for (int i = 0; i < dirs.length; i++) {
			float angle = i * 45f;
			float diff = ((angle - yaw + 540f) % 360f) - 180f;
			if (Math.abs(diff) < 60f) {
				int x = (int) (60 + diff * 1.0f);
				int alpha = (int) (255 * (1f - Math.abs(diff) / 60f));
				g.text(font, dirs[i], x, 4, (alpha << 24) | 0x00FFFFFF);
			}
		}
		Draw.rect(g, 59, 0, 2, 3, 0xFF00C896);
	}

	private static void drawWatermark(GuiGraphicsExtractor g, Font font, WatermarkModule m) {
		String s = "Jade Client";
		if (m.showVersion.get()) {
			s += " " + com.jadeclient.JadeClient.VERSION;
		}
		g.text(font, s, 0, 0, 0xFF00C896);
		if (!m.customText.get().isEmpty()) {
			g.text(font, m.customText.get(), 0, 11, 0xFFFFFFFF);
		}
	}
}
