package com.jadeclient.ui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Bottom-right toast notifications for toggles, config saves, errors.
 * Slides in, holds ~2s, fades out.
 */
public final class ToastManager {

	public record Toast(Component text, long bornAt, int accent) {
	}

	private static final List<Toast> active = new ArrayList<>();
	private static final long LIFE_MS = 2200;

	public static void info(String message) {
		push(Component.literal(message), Theme.accent);
	}

	public static void error(String message) {
		push(Component.literal(message), 0xFFFF6B6B);
	}

	public static void push(Component text, int accent) {
		active.add(new Toast(text, System.currentTimeMillis(), accent));
		if (active.size() > 5) {
			active.removeFirst();
		}
	}

	public static void render(GuiGraphicsExtractor g) {
		long now = System.currentTimeMillis();
		active.removeIf(t -> now - t.bornAt() > LIFE_MS);

		var mc = Minecraft.getInstance();
		int y = mc.getWindow().getGuiScaledHeight() - 24;

		for (Toast toast : active) {
			float age = (now - toast.bornAt()) / 1000f;
			float alpha = age < 0.15f ? age / 0.15f : age > 1.9f ? Math.max(0f, 1f - (age - 1.9f) / 0.3f) : 1f;
			int a = (int) (alpha * 255) << 24;

			int width = mc.font.width(toast.text()) + 16;
			int x = mc.getWindow().getGuiScaledWidth() - width - 8;

			com.jadeclient.ui.render.Draw.roundedRect(g, x, y, width, 16, 4,
					a | (Theme.bgPanel & 0x00FFFFFF));
			com.jadeclient.ui.render.Draw.rect(g, x, y, 2, 16, a & toast.accent());
			g.text(mc.font, toast.text(), x + 8, y + 4, a | 0x00FFFFFF);
			y -= 20;
		}
	}

	public static void clear() {
		active.clear();
	}
}
