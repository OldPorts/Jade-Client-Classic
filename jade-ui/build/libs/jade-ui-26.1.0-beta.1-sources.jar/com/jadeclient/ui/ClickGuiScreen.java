package com.jadeclient.ui;

import com.jadeclient.JadeClient;
import com.jadeclient.core.Category;
import com.jadeclient.core.Module;
import com.jadeclient.core.ModuleManager;
import com.jadeclient.core.util.FuzzyMatcher;
import com.jadeclient.ui.render.Draw;
import com.jadeclient.modules.hud.HudModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * The Jade ClickGUI: a centered, glassy, three-pane screen in the Lunar /
 * Feather style.
 *
 *   [ categories ]   [ module list ]   [ settings panel ]
 *
 * Opened with Right Shift (default). ESC closes. Search bar filters modules
 * with fuzzy matching. The jade shimmer runs along the top edge.
 */
public class ClickGuiScreen extends Screen {

	private static final int OPEN_ANIM_MS = 170;

	private Category selectedCategory = Category.PERFORMANCE;
	private Module selectedModule;
	private String search = "";

	// Per-module animated toggle position (0..1), updated each frame.
	private final java.util.Map<Object, Float> toggleAnim = new java.util.HashMap<>();
	private long openTime;

	// Scroll offsets per pane
	private float moduleScroll;
	private float settingsScroll;

	// Hover tracking for soft highlight
	private int hoverModuleIdx = -1;

	public ClickGuiScreen() {
		super(Component.literal("Jade Client"));
	}

	public static void open() {
		Minecraft.getInstance().setScreen(new ClickGuiScreen());
	}

	@Override
	protected void init() {
		openTime = System.currentTimeMillis();
		moduleScroll = 0;
		settingsScroll = 0;
	}

	// MC 26.1: render() became extractRenderState(GuiGraphicsExtractor, ...).
	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		int w = width;
		int h = height;

		// Dim backdrop (stands in for glassmorphism blur at every GUI scale)
		g.fillGradient(0, 0, w, h, 0x88000000, 0x88000000);
		// Panel geometry: centered 480x260 GUI units
		int pw = Math.min(480, w - 40);
		int ph = Math.min(260, h - 40);
		int px = (w - pw) / 2;
		int py = (h - ph) / 2;

		float openProgress = Theme.ease((System.currentTimeMillis() - openTime) / (float) OPEN_ANIM_MS);

		// Panel background
		Draw.roundedRect(g, px, py, pw, ph, 8, Theme.bg);
		Draw.roundedRect(g, px, py, pw, ph, 8, (int) (openProgress * 255) << 24 | 0x161A22 & 0x00FFFFFF);

		// Jade shimmer along the top edge
		renderShimmer(g, px, py, pw, openProgress);

		// Title
		g.text(font, "Jade Client", px + 12, py + 8, Theme.accent);
		g.text(font, JadeClient.VERSION, px + pw - font.width(JadeClient.VERSION) - 12, py + 8,
				Theme.textDim);

		// Search bar (top center)
		int searchW = 140;
		int searchX = px + (pw - searchW) / 2;
		Draw.roundedRect(g, searchX, py + 6, searchW, 14, 4, Theme.bgCard);
		g.text(font, search.isEmpty() ? "Search..." : search, searchX + 6, py + 10, Theme.textDim);

		// Panes
		int paneTop = py + 26;
		int paneBottom = py + ph - 8;

		renderCategories(g, px + 8, paneTop, 96, paneBottom - paneTop, mouseX, mouseY);
		renderModuleList(g, px + 112, paneTop, 150, paneBottom - paneTop, mouseX, mouseY);
		renderSettings(g, px + 270, paneTop, pw - 278, paneBottom - paneTop, mouseX, mouseY);
	}

	private void renderShimmer(GuiGraphicsExtractor g, int px, int py, int pw, float open) {
		long t = System.currentTimeMillis();
		if (Theme.reducedMotion) {
			Draw.rect(g, px + 8, py, pw - 16, 2, Theme.accent);
			return;
		}
		// Moving highlight across a static accent line.
		Draw.rect(g, px + 8, py, pw - 16, 2, Theme.withAlpha(Theme.accent, 90));
		int sweep = (int) ((t / 12) % (pw - 16 + 120)) - 60;
		int sw = 90;
		int sx = px + 8 + sweep;
		int x0 = Math.max(px + 8, sx);
		int x1 = Math.min(px + pw - 8, sx + sw);
		if (x1 > x0) {
			Draw.rect(g, x0, py, x1 - x0, 2, Theme.accent);
		}
	}

	private void renderCategories(GuiGraphicsExtractor g, int x, int y, int w, int h, int mx, int my) {
		Draw.rect(g, x + w, y, 1, h, Theme.border);
		Category[] cats = Category.values();
		int rowH = 26;
		for (int i = 0; i < cats.length; i++) {
			Category cat = cats[i];
			int cy = y + i * rowH + 4;
			boolean selected = cat == selectedCategory;
			boolean hovered = mx >= x && mx < x + w && my >= cy && my < cy + rowH - 6;

			if (selected) {
				Draw.roundedRect(g, x, cy, w - 6, rowH - 6, 4, Theme.withAlpha(Theme.accent, 40));
				Draw.rect(g, x, cy + 3, 2, rowH - 12, Theme.accent);
			} else if (hovered) {
				Draw.roundedRect(g, x, cy, w - 6, rowH - 6, 4, Theme.withAlpha(Theme.text, 15));
			}
			int textX = x + 10;
			int color = selected ? Theme.accent : hovered ? Theme.text : Theme.textDim;
			g.text(font, cat.displayName(), textX, cy + (rowH - 12 - font.lineHeight) / 2 + 3, color);
		}
	}

	private void renderModuleList(GuiGraphicsExtractor g, int x, int y, int w, int h, int mx, int my) {
		Draw.rect(g, x + w, y, 1, h, Theme.border);

		List<Module> modules = visibleModules();
		int rowH = 24;
		int maxRows = h / rowH;
		moduleScroll = Math.max(0, Math.min(modules.size() - maxRows, moduleScroll));

		g.enableScissor(x, y, x + w, y + h);
		for (int i = 0; i < modules.size(); i++) {
			Module m = modules.get(i);
			int cy = y + (int) ((i - moduleScroll) * rowH) + 2;
			if (cy + rowH < y || cy > y + h) {
				continue;
			}
			boolean hovered = mx >= x && mx < x + w && my >= cy && my < cy + rowH - 4;
			if (hovered) {
				hoverModuleIdx = i;
				Draw.roundedRect(g, x + 2, cy, w - 10, rowH - 4, 4, Theme.withAlpha(Theme.text, 12));
			}
			if (selectedModule == m) {
				Draw.roundedRect(g, x + 2, cy, w - 10, rowH - 4, 4, Theme.withAlpha(Theme.accent, 28));
			}

			// Name
			int nameColor = m.isEnabled() ? Theme.accent : Theme.text;
			g.text(font, m.name(), x + 8, cy + 7, nameColor);

			// Toggle pill (animated)
			float anim = toggleAnim.computeIfAbsent(m, k -> m.isEnabled() ? 1f : 0f);
			float target = m.isEnabled() ? 1f : 0f;
			anim += (target - anim) * 0.25f;
			toggleAnim.put(m, anim);

			int pillW = 22;
			int pillX = x + w - 8 - pillW;
			int pillY = cy + (rowH - 4 - 10) / 2;
			int pillBg = blend(Theme.bgCard, Theme.accent, anim);
			Draw.roundedRect(g, pillX, pillY, pillW, 10, 5, pillBg);
			int knobX = pillX + 2 + (int) (anim * (pillW - 10));
			Draw.roundedRect(g, knobX, pillY + 2, 6, 6, 3, 0xFFFFFFFF);
		}
		g.disableScissor();
	}

	private int blend(int from, int to, float t) {
		int a0 = (from >>> 24), r0 = (from >> 16) & 0xFF, g0 = (from >> 8) & 0xFF, b0 = from & 0xFF;
		int a1 = (to >>> 24), r1 = (to >> 16) & 0xFF, g1 = (to >> 8) & 0xFF, b1 = to & 0xFF;
		int a = (int) (a0 + (a1 - a0) * t);
		int r = (int) (r0 + (r1 - r0) * t);
		int gg = (int) (g0 + (g1 - g0) * t);
		int b = (int) (b0 + (b1 - b0) * t);
		return (a << 24) | (r << 16) | (gg << 8) | b;
	}

	private void renderSettings(GuiGraphicsExtractor g, int x, int y, int w, int h, int mx, int my) {
		if (selectedModule == null) {
			g.centeredText(font, "Select a module", x + w / 2, y + h / 2 - 4, Theme.textDim);
			return;
		}
		g.text(font, selectedModule.name(), x + 4, y + 2, Theme.text);
		g.text(font, Component.translatable(selectedModule.descriptionKey()).getString(),
				x + 4, y + 14, Theme.textDim);

		int cy = y + 30;
		for (var setting : selectedModule.settings()) {
			if (cy > y + h - 12) {
				break;
			}
			if (setting instanceof com.jadeclient.core.setting.BooleanSetting b) {
				g.text(font, prettify(setting.id()), x + 4, cy, Theme.text);
				int pillX = x + w - 30;
				String key = "s:" + setting.id();
				float anim = toggleAnim.computeIfAbsent(new SettingAnimKey(key), k -> b.get() ? 1f : 0f);
				float target = b.get() ? 1f : 0f;
				anim += (target - anim) * 0.25f;
				toggleAnim.put(new SettingAnimKey(key), anim);
				Draw.roundedRect(g, pillX, cy - 1, 22, 10, 5, blend(Theme.bgCard, Theme.accent, anim));
				int knobX = pillX + 2 + (int) (anim * 12);
				Draw.roundedRect(g, knobX, cy + 1, 6, 6, 3, 0xFFFFFFFF);
				cy += 18;
			} else if (setting instanceof com.jadeclient.core.setting.FloatSetting f) {
				g.text(font, prettify(setting.id()) + ": " + String.format("%.1f", f.get()), x + 4, cy,
						Theme.text);
				renderSlider(g, x + 4, cy + 10, w - 8, f.get(), f.min(), f.max());
				cy += 26;
			} else if (setting instanceof com.jadeclient.core.setting.IntSetting i) {
				g.text(font, prettify(setting.id()) + ": " + i.get(), x + 4, cy, Theme.text);
				renderSlider(g, x + 4, cy + 10, w - 8, i.get(), i.min(), i.max());
				cy += 26;
			} else if (setting instanceof com.jadeclient.core.setting.EnumSetting e) {
				g.text(font, prettify(setting.id()), x + 4, cy, Theme.text);
				g.text(font, "< " + e.get() + " >", x + w - 8 - font.width("< " + e.get() + " >"), cy,
						Theme.accent);
				cy += 18;
			} else if (setting instanceof com.jadeclient.core.setting.TextSetting t) {
				g.text(font, prettify(setting.id()), x + 4, cy, Theme.text);
				g.text(font, t.get().isEmpty() ? "(empty)" : t.get(), x + 4, cy + 10, Theme.textDim);
				cy += 22;
			}
		}
	}

	private final java.util.Map<String, Float> sliderDrag = new java.util.HashMap<>();

	private void renderSlider(GuiGraphicsExtractor g, int x, int y, int w, double value, double min, double max) {
		float t = (float) ((value - min) / (max - min));
		Draw.roundedRect(g, x, y, w, 4, 2, Theme.bgCard);
		int fill = (int) (w * Math.max(0f, Math.min(1f, t)));
		Draw.roundedRect(g, x, y, fill, 4, 2, Theme.accent);
		Draw.roundedRect(g, x + fill - 3, y - 2, 6, 8, 3, 0xFFFFFFFF);
		// store slider geometry for click handling
		sliderDrag.put("x", (float) x);
		sliderDrag.put("y", (float) y);
		sliderDrag.put("w", (float) w);
	}

	private String prettify(String id) {
		String[] parts = id.split("_");
		StringBuilder sb = new StringBuilder();
		for (String p : parts) {
			if (sb.length() > 0) {
				sb.append(' ');
			}
			sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1));
		}
		return sb.toString();
	}

	private List<Module> visibleModules() {
		List<Module> out = new ArrayList<>();
		if (!search.isEmpty()) {
			for (Module m : com.jadeclient.JadeClient.modules().modules()) {
				if (FuzzyMatcher.score(search, m.name()) >= 0) {
					out.add(m);
				}
			}
		} else {
			out.addAll(com.jadeclient.JadeClient.modules().byCategory(selectedCategory));
		}
		return out;
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubled) {
		double mouseX = event.x();
		double mouseY = event.y();
		int button = event.button();

		int pw = Math.min(480, width - 40);
		int ph = Math.min(260, height - 40);
		int px = (width - pw) / 2;
		int py = (height - ph) / 2;

		// Click outside the panel closes it (Lunar behavior).
		if (mouseX < px || mouseX > px + pw || mouseY < py || mouseY > py + ph) {
			close();
			return true;
		}

		int paneTop = py + 26;

		// Category pane clicks
		int catX = px + 8;
		if (mouseX >= catX && mouseX < catX + 96 && mouseY >= paneTop) {
			int idx = (int) ((mouseY - paneTop - 4) / 26);
			Category[] cats = Category.values();
			if (idx >= 0 && idx < cats.length) {
				selectedCategory = cats[idx];
				selectedModule = null;
				search = "";
				return true;
			}
		}

		// Module pane clicks
		int modX = px + 112;
		if (mouseX >= modX && mouseX < modX + 150 && mouseY >= paneTop) {
			List<Module> modules = visibleModules();
			int idx = (int) ((mouseY - paneTop - 2) / 24 + moduleScroll);
			if (idx >= 0 && idx < modules.size()) {
				Module m = modules.get(idx);
				double relX = mouseX - (modX + 150 - 30);
				if (relX > 0) {
					m.toggle(); // clicked the pill
					ToastManager.info(m.name() + " " + (m.isEnabled() ? "enabled" : "disabled"));
					com.jadeclient.config.JadeConfig.get().save();
				} else {
					selectedModule = m;
				}
				return true;
			}
		}

		return super.mouseClicked(event, doubled);
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
		double mouseX = event.x();
		double mouseY = event.y();
		int button = event.button();
		// Slider dragging in the settings pane
		if (selectedModule != null && sliderDrag.containsKey("x") && button == 0) {
			float sx = sliderDrag.get("x");
			float sy = sliderDrag.get("y");
			float sw = sliderDrag.get("w");
			if (mouseY >= sy - 4 && mouseY <= sy + 8 && mouseX >= sx && mouseX <= sx + sw) {
				float t = (float) ((mouseX - sx) / sw);
				for (var setting : selectedModule.settings()) {
					if (setting instanceof com.jadeclient.core.setting.FloatSetting f) {
						f.set((float) (f.min() + t * (f.max() - f.min())));
					} else if (setting instanceof com.jadeclient.core.setting.IntSetting i) {
						i.set((int) Math.round(i.min() + t * (i.max() - i.min())));
					}
				}
				return true;
			}
		}
		return super.mouseDragged(event, dx, dy);
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
		int keyCode = event.key();
		if (keyCode == 256) { // ESC
			close();
			return true;
		}
		if (keyCode == 259) { // Backspace
			if (!search.isEmpty()) {
				search = search.substring(0, search.length() - 1);
			}
			return true;
		}
		// Typing into search
		if (keyCode >= 32 && keyCode < 127) {
			char c = (char) keyCode;
			if (Character.isLetterOrDigit(c) || c == ' ' || c == '_' || c == '-') {
				search += c;
				return true;
			}
		}
		return super.keyPressed(event);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void onClose() {
		com.jadeclient.config.JadeConfig.get().save();
		super.onClose();
	}

	private void close() {
		Minecraft.getInstance().setScreen(null);
	}

	/** Wrapper so setting toggles can share the animation map with modules. */
	private record SettingAnimKey(String id) {
	}
}
