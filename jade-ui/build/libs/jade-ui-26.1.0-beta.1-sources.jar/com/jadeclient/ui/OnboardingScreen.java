package com.jadeclient.ui;

import com.jadeclient.JadeClient;
import com.jadeclient.ui.render.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * First-launch onboarding: 3 steps - theme, performance preset, keybind
 * summary. Only shows once; writes a flag into the Jade config dir.
 */
public class OnboardingScreen extends Screen {

	private int step;
	private Theme.Mode chosenTheme = Theme.Mode.DARK;
	private String chosenPreset = "Balanced";

	public OnboardingScreen() {
		super(Component.literal("Welcome to Jade"));
	}

	public static boolean shouldShow() {
		return !java.nio.file.Files.exists(
				com.jadeclient.config.JadeConfig.get().root().resolve("onboarded"));
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		g.fillGradient(0, 0, width, height, 0xEE0E1116, 0xEE0E1116);

		int pw = 220;
		int ph = 130;
		int px = (width - pw) / 2;
		int py = (height - ph) / 2;

		Draw.roundedRect(g, px, py, pw, ph, 8, Theme.bgPanel);
		Draw.rect(g, px + 8, py, pw - 16, 2, Theme.accent);

		String title = switch (step) {
			case 0 -> "Pick your theme";
			case 1 -> "Choose a performance preset";
			default -> "You're all set!";
		};
		g.centeredText(font, title, width / 2, py + 16, Theme.text);

		if (step == 0) {
			String[] themes = {"Dark", "Light", "Jade"};
			for (int i = 0; i < themes.length; i++) {
				int bx = px + 16 + i * 64;
				boolean sel = chosenTheme.ordinal() == i;
				Draw.roundedRect(g, bx, py + 40, 56, 22, 5,
						sel ? Theme.accent : Theme.bgCard);
				g.centeredText(font, themes[i], bx + 28, py + 47,
						sel ? 0xFF0E1116 : Theme.text);
			}
		} else if (step == 1) {
			String[] presets = {"Low", "Balanced", "High", "Jade-Max"};
			for (int i = 0; i < presets.length; i++) {
				int bx = px + 12 + i * 50;
				boolean sel = chosenPreset.equals(presets[i]);
				Draw.roundedRect(g, bx, py + 40, 46, 22, 5,
						sel ? Theme.accent : Theme.bgCard);
				g.centeredText(font, presets[i], bx + 23, py + 47,
						sel ? 0xFF0E1116 : Theme.text);
			}
		} else {
			g.centeredText(font, "RShift - Open Jade menu", width / 2, py + 44, Theme.text);
			g.centeredText(font, "RShift again - HUD editor", width / 2, py + 58, Theme.text);
			g.centeredText(font, "C - Zoom", width / 2, py + 72, Theme.text);
			g.centeredText(font, "Everything else lives in the menu.", width / 2, py + 90, Theme.textDim);
		}

		// Next / Finish button
		String btn = step < 2 ? "Next" : "Finish";
		Draw.roundedRect(g, px + pw - 56, py + ph - 26, 44, 16, 5, Theme.accent);
		g.centeredText(font, btn, px + pw - 34, py + ph - 22, 0xFF0E1116);
	}

	@Override
	public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent event, boolean doubled) {
		double mouseX = event.x();
		double mouseY = event.y();
		int pw = 220;
		int ph = 130;
		int px = (width - pw) / 2;
		int py = (height - ph) / 2;

		if (step == 0) {
			for (int i = 0; i < 3; i++) {
				int bx = px + 16 + i * 64;
				if (mouseX >= bx && mouseX <= bx + 56 && mouseY >= py + 40 && mouseY <= py + 62) {
					chosenTheme = Theme.Mode.values()[i];
					Theme.apply(chosenTheme);
					return true;
				}
			}
		} else if (step == 1) {
			String[] presets = {"Low", "Balanced", "High", "Jade-Max"};
			for (int i = 0; i < presets.length; i++) {
				int bx = px + 12 + i * 50;
				if (mouseX >= bx && mouseX <= bx + 46 && mouseY >= py + 40 && mouseY <= py + 62) {
					chosenPreset = presets[i];
					com.jadeclient.ui.JadeClientClient.applyPreset(chosenPreset);
					return true;
				}
			}
		}

		// Next / Finish
		if (mouseX >= px + pw - 56 && mouseX <= px + pw - 12
				&& mouseY >= py + ph - 26 && mouseY <= py + ph - 10) {
			step++;
			if (step > 2) {
				finish();
			}
			return true;
		}
		return super.mouseClicked(event, doubled);
	}

	private void finish() {
		try {
			java.nio.file.Files.writeString(
					com.jadeclient.config.JadeConfig.get().root().resolve("onboarded"), "1");
		} catch (Exception ignored) {
		}
		com.jadeclient.config.JadeConfig.get().save();
		ToastManager.info("Welcome to Jade Client");
		Minecraft.getInstance().setScreen(null);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
