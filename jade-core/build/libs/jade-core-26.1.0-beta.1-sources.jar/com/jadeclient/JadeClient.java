package com.jadeclient;

import com.jadeclient.config.ConfigSpi;
import com.jadeclient.config.JadeConfig;
import com.jadeclient.config.JadeConfigImpl;
import com.jadeclient.core.Module;
import com.jadeclient.core.ModuleManager;
import com.jadeclient.core.event.EventBridge;
import com.jadeclient.core.event.EventBus;
import com.jadeclient.core.spi.ConfigSpiImpl;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ServiceLoader;

/**
 * Jade Client entrypoint. Boot order:
 * 1. register all modules (via ServiceLoader, so modules live in their own gradle module)
 * 2. register the event bridge
 * 3. load config (applies persisted settings + enabled states)
 */
public class JadeClient implements ModInitializer, ClientModInitializer {

	public static final String MOD_ID = "jade-client";
	public static final String VERSION = "26.1.0-beta.1";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	private static ModuleManager moduleManager;

	@Override
	public void onInitialize() {
		moduleManager = new ModuleManager();
		ModuleRegistrar.registerAll(moduleManager);
		ModuleRegistrar.fireAfterModules(moduleManager);

		EventBridge.register();
		moduleManager.init();

		// Re-install the config store with the real SPI, then load state.
		ConfigSpi spi = new ConfigSpiImpl(moduleManager);
		new JadeConfigImpl(configRoot(), spi).load();

		LOGGER.info("Jade Client {} ready - {} modules registered", VERSION, moduleManager.modules().size());
	}

	private static java.nio.file.Path configRoot() {
		return FabricLoader.getInstance().getGameDir().resolve("jade");
	}

	@Override
	public void onInitializeClient() {
		// First-launch onboarding lives on the client side (jade-ui screens).
		// The ui module self-initializes via its own entrypoint; nothing to
		// do here beyond logging.
		if (FabricLoader.getInstance().isDevelopmentEnvironment()) {
			LOGGER.info("Jade development environment detected");
		}
	}

	public static ModuleManager modules() {
		return moduleManager;
	}

	public static net.minecraft.resources.Identifier id(String path) {
		return net.minecraft.resources.Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
