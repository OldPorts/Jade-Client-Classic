package com.jadeclient.core.event;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;

/**
 * Bridges Fabric lifecycle events onto the Jade event bus so modules and
 * mixins only ever need to talk to {@link EventBus}.
 */
public final class EventBridge {

	private EventBridge() {
	}

	public static void register() {
		ClientTickEvents.END_CLIENT_TICK.register(minecraft -> EventBus.get().post(new EventBus.ClientTick()));
	}

	/**
	 * Posts a frame event with the current FPS and frametime. Called from the
	 * FPS tracker each frame.
	 */
	public static void postFrame(float fps, float frameTimeMs) {
		EventBus.get().post(new EventBus.Frame(fps, frameTimeMs));
	}

	/** Convenience accessor for modules that need the vanilla client. */
	public static Minecraft client() {
		return Minecraft.getInstance();
	}
}
