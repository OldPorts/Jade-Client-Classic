package com.jadeclient.perf;

import com.jadeclient.ModuleRegistrar;
import com.jadeclient.core.ModuleManager;
import net.fabricmc.api.ClientModInitializer;

/**
 * jade-performance client entrypoint: wires the mixin bridge to the module
 * manager once modules are registered.
 */
public final class PerformanceInit implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		ModuleRegistrar.runAfterModules(manager ->
				JadePerfBridge.install(
						() -> manager.byId("fps_boost") instanceof PerformanceModule m && m.isEnabled(),
						() -> manager.byId("fps_boost") instanceof PerformanceModule m ? m : null));
	}
}
