package com.jadeclient.perf.mixin;

import com.jadeclient.perf.PerformanceAccess;
import com.jadeclient.perf.PerformanceModule;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.util.RandomSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Particle density limiter. A 0..400% multiplier: below 100% randomly drops
 * particles (never spawns extra), rain splashes can be cut entirely.
 */
@Mixin(ParticleEngine.class)
public abstract class ParticleEngineMixin {

	private final RandomSource jade$random = RandomSource.create();

	@Inject(method = "add", at = @At("HEAD"), cancellable = true)
	private void jade$limitParticles(Particle particle, CallbackInfo ci) {
		PerformanceModule perf = PerformanceAccess.perf();
		if (perf == null || !perf.isEnabled()) {
			return;
		}
		if (perf.noRainSplashes.get() && particle instanceof net.minecraft.client.particle.WaterDropParticle) {
			ci.cancel();
			return;
		}
		if (!perf.limitParticles.get()) {
			return;
		}
		int percent = perf.particleMultiplier.get();
		if (percent >= 100) {
			return;
		}
		if (jade$random.nextInt(100) >= percent) {
			ci.cancel();
		}
	}
}
