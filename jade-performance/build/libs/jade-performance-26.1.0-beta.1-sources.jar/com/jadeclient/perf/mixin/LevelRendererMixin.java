package com.jadeclient.perf.mixin;

import com.jadeclient.perf.PerformanceAccess;
import com.jadeclient.perf.PerformanceModule;
import com.jadeclient.perf.culling.CullingState;
import net.minecraft.client.renderer.LevelRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Frame-level hook for chunk culling stats. The per-section checks live in
 * vanilla + Sodium; Jade only tracks state so the HUD/benchmark can report
 * culled-section counts.
 */
@Mixin(LevelRenderer.class)
public abstract class LevelRendererMixin {

	@Inject(method = "renderLevel", at = @At("HEAD"))
	private void jade$beginFrame(CallbackInfo ci) {
		PerformanceModule perf = PerformanceAccess.perf();
		if (perf != null && perf.isEnabled() && perf.smartFrustum.get()) {
			CullingState.beginFrame();
		} else {
			CullingState.endFrame();
		}
	}

	@Inject(method = "renderLevel", at = @At("RETURN"))
	private void jade$endFrame(CallbackInfo ci) {
		CullingState.endFrame();
	}
}
