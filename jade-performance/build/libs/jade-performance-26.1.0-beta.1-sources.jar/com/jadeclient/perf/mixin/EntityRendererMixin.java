package com.jadeclient.perf.mixin;

import com.jadeclient.perf.PerformanceAccess;
import com.jadeclient.perf.PerformanceModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Entity render distance: entities beyond the configured radius (blocks)
 * are skipped. 0 = vanilla. Complements Sodium's culling; when Jade is off
 * this is a no-op.
 */
@Mixin(net.minecraft.client.renderer.entity.EntityRenderDispatcher.class)
public abstract class EntityRendererMixin {

	@Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
	private void jade$entityRenderDistance(Entity entity, Frustum frustum, double x, double y, double z,
			CallbackInfoReturnable<Boolean> cir) {
		PerformanceModule perf = PerformanceAccess.perf();
		if (perf == null || !perf.isEnabled()) {
			return;
		}
		int dist = perf.entityRenderDistance.get();
		if (dist <= 0 || entity == null) {
			return;
		}
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || entity == mc.player) {
			return;
		}
		if (entity.distanceToSqr(mc.player) > (double) dist * dist) {
			cir.setReturnValue(false);
		}
	}
}
