package com.jadeclient.perf.mixin;

import com.jadeclient.core.perf.FpsTracker;
import com.jadeclient.perf.PerformanceAccess;
import com.jadeclient.perf.PerformanceModule;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks the client run loop for:
 *  - frametime measurement (FPS HUD, 1% lows, benchmark)
 *  - dynamic FPS cap while the window is unfocused (GPU/battery savings)
 *
 * Everything is gated on the Master FPS Boost module so vanilla and Sodium
 * behavior is untouched when Jade is off.
 */
@Mixin(Minecraft.class)
public abstract class MinecraftMixin {

	@Inject(method = "run", at = @At("HEAD"))
	private void jade$initTracker(CallbackInfo ci) {
		FpsTracker.get().reset();
	}

	@Inject(method = "runTick", at = @At("RETURN"))
	private void jade$onFrame(boolean renderLevel, CallbackInfo ci) {
		Minecraft mc = (Minecraft) (Object) this;
		float deltaMs = PerformanceAccess.lastFrameDeltaMs();
		FpsTracker.get().onFrame(deltaMs);

		// Dynamic unfocused FPS cap: brief sleep after the frame is done.
		PerformanceModule perf = PerformanceAccess.perf();
		if (perf != null && perf.isEnabled() && !mc.isWindowActive()) {
			float cap = perf.unfocusedFpsCap.get();
			if (cap >= 5f) {
				long frameNs = (long) (1_000_000_000f / cap);
				long elapsed = System.nanoTime() - PerformanceAccess.lastFrameStart();
				long sleepMs = (frameNs - elapsed) / 1_000_000L;
				if (sleepMs > 0 && sleepMs < 200) {
					GLFW.glfwWaitEventsTimeout(sleepMs / 1000.0);
				}
			}
		}
	}
}
