package com.jadeclient.perf;

import net.minecraft.client.Minecraft;

/**
 * Static bridge between mixins and the perf settings. Avoids repeated
 * lookups inside hot paths.
 */
public final class PerformanceAccess {

	private PerformanceAccess() {
	}

	/** Nanosecond timestamp of the previous frame start. */
	private static volatile long lastFrameStart = System.nanoTime();
	private static volatile float lastDeltaMs;

	public static long lastFrameStart() {
		return lastFrameStart;
	}

	public static float lastFrameDeltaMs() {
		long now = System.nanoTime();
		lastDeltaMs = (now - lastFrameStart) / 1_000_000f;
		lastFrameStart = now;
		return lastDeltaMs;
	}

	/** Master FPS Boost on? Fast bail-out used by every perf mixin. */
	public static boolean perfEnabled() {
		return JadePerfBridge.fpsBoostEnabled();
	}

	public static PerformanceModule perf() {
		return JadePerfBridge.module();
	}

	public static boolean windowFocused() {
		return Minecraft.getInstance().isWindowActive();
	}

	/** True when the unfocused cap should throttle rendering. */
	public static boolean shouldThrottleUnfocused() {
		PerformanceModule m = perf();
		return m != null && m.isEnabled() && !windowFocused();
	}
}
