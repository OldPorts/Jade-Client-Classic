package com.jadeclient.cosmetics;

import com.jadeclient.JadeClient;
import com.jadeclient.modules.visual.CrosshairModule;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;

/**
 * jade-cosmetics client entrypoint: hooks the crosshair overlay.
 */
public final class JadeCosmeticsClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		HudElementRegistry.addLast(JadeClient.id("crosshair_element"), (graphics, delta) -> {
			var mc = net.minecraft.client.Minecraft.getInstance();
			if (mc.player == null || mc.options.hideGui) {
				return;
			}
			var crosshair = JadeClient.modules().byId("crosshair");
			if (crosshair instanceof CrosshairModule m && m.isEnabled()
					&& !mc.options.getCameraType().isFirstPerson()) {
				return; // custom crosshair only makes sense in first person
			}
			// Center of the screen in GUI coordinates
			int cx = graphics.guiWidth() / 2;
			int cy = graphics.guiHeight() / 2;
			CrosshairRenderer.render(graphics, cx, cy);
		});
	}
}
