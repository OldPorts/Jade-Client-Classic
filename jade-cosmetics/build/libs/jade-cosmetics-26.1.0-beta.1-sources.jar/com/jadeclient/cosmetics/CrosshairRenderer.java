package com.jadeclient.cosmetics;

import com.jadeclient.JadeClient;
import com.jadeclient.ui.render.Draw;
import com.jadeclient.modules.visual.CrosshairModule;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Draws the custom crosshair when the Crosshair Editor module is enabled.
 * Purely decorative - replaces the vanilla sprite only.
 */
public final class CrosshairRenderer {

	private CrosshairRenderer() {
	}

	public static void render(GuiGraphicsExtractor g, int cx, int cy) {
		var module = JadeClient.modules().byId("crosshair");
		if (!(module instanceof CrosshairModule m) || !m.isEnabled()) {
			return;
		}
		int size = m.size.get();
		int thick = m.thickness.get();
		int color = m.rainbow.get()
				? 0xFF000000 | (int) (System.currentTimeMillis() / 8 % 0xFFFFFF)
				: m.color.get();

		switch (m.style.get()) {
			case "Dot" -> Draw.roundedRect(g, cx - size / 2, cy - size / 2, size, size, 1, color);
			case "Cross" -> {
				Draw.rect(g, cx - size, cy - thick / 2, size * 2, thick, color);
				Draw.rect(g, cx - thick / 2, cy - size, thick, size * 2, color);
			}
			case "Circle" -> drawCircle(g, cx, cy, size, thick, color);
			case "Circle Dot" -> {
				drawCircle(g, cx, cy, size, thick, color);
				Draw.roundedRect(g, cx - 1, cy - 1, 2, 2, 1, color);
			}
			case "Plus Gap" -> {
				int gap = 2;
				Draw.rect(g, cx - size - gap, cy - thick / 2, size, thick, color);
				Draw.rect(g, cx + gap, cy - thick / 2, size, thick, color);
				Draw.rect(g, cx - thick / 2, cy - size - gap, thick, size, color);
				Draw.rect(g, cx - thick / 2, cy + gap, thick, size, color);
			}
			case "T Shape" -> {
				Draw.rect(g, cx - size, cy - thick / 2, size * 2, thick, color);
				Draw.rect(g, cx - thick / 2, cy, thick, size, color);
			}
		}
	}

	/** Pixel circle (approximation good enough at GUI scale 1-4). */
	private static void drawCircle(GuiGraphicsExtractor g, int cx, int cy, int r, int thick, int color) {
		for (int a = 0; a < 360; a += 6) {
			double rad = Math.toRadians(a);
			int x = cx + (int) Math.round(Math.cos(rad) * r);
			int y = cy + (int) Math.round(Math.sin(rad) * r);
			g.fill(x, y, x + thick, y + thick, color);
		}
	}
}
